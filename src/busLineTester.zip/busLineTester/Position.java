package busLineTester;

public interface Position {
	public int getRow();
	public int getCol();	
}
